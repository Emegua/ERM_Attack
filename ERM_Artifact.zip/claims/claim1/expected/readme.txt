Expected Results:
- LTspice waveform showing inverter output voltage degradation
- Negative half-cycle reduction consistent with Figure 5 in the paper
