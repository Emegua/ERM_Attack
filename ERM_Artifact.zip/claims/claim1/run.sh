#!/bin/bash
echo "Claim 1 requires manual execution in LTspice."
echo "Steps:"
echo "  1. Open artifact/LTspice/DC-AC.asc in LTspice XVII."
echo "  2. Run the simulation."
echo "  3. Compare output waveforms against expected/plots."
