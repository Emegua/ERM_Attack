#!/bin/bash
echo "Claim 3 requires manual execution in ETAP 19.0.1."
echo "Steps:"
echo "  1. Open artifact/ETAP/ieee_13/ieee_13.OTI in ETAP."
echo "  2. Run the simulation."
echo "  3. Compare output to expected/plots."
